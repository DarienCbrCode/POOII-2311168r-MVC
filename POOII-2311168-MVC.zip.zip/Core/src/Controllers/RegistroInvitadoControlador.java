package controllers;

import core.Controller;
import models.Invitado;
import models.InvitadoIO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class RegistroInvitadoControlador extends Controller {
    private JPanel ventanaPrincipalJPanel;
    private JTextField nombreTextField;
    private JTextField apellidoTextField;
    private JButton registrarButton;
    private JButton resetearButton;

    @Override
    public void run() {
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreTextField.getText();
                String apellido = apellidoTextField.getText();
                Invitado invitado = new Invitado(nombre, apellido);
                try {
                    InvitadoIO.guardarInvitado(invitado);
                    JOptionPane.showMessageDialog(null, "Invitado registrado con éxito");
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error al registrar invitado: " + ex.getMessage());
                }
            }
        });

        resetearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nombreTextField.setText("");
                apellidoTextField.setText("");
            }
        });
    }
}
