package models;

public enum Frequency
{
    DAILY, WEEKLY, MONTHLY;
}