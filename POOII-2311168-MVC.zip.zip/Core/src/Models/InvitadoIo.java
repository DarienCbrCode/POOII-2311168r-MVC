package models;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class InvitadoIO {
    private static final String FILE_PATH = "invitados.txt";

    public static void guardarInvitado(Invitado invitado) throws IOException {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            file.createNewFile();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(invitado.toString());
            writer.newLine();
        }
    }
}
