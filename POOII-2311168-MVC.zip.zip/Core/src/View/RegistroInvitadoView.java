import javax.swing.*;

    public class RegistroInvitadoView {
    private JTextField nombreTextField;
    private JTextField apellidoTextField;
    private JButton registrarButton;
    private JButton resetearButton;
    private JPanel ventanaPrincipalJPanel;

    public RegistroInvitadoView() {
        JFrame frame = new JFrame("Registrar Invitado");
        frame.setContentPane(ventanaPrincipalJPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JTextField getNombreTextField() {
        return nombreTextField;
    }

    public JTextField getApellidoTextField() {
        return apellidoTextField;
    }

    public JButton getRegistrarButton() {
        return registrarButton;
    }

    public JButton getResetearButton() {
        return resetearButton;
    }
}
